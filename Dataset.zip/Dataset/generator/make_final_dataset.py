from pathlib import Path
import os, sys, csv, json, math, random, shutil, zipfile, hashlib
from PIL import Image, ImageDraw, ImageFont

GENERATION_SEED = 20261004
random.seed(GENERATION_SEED)

OUT = Path(os.environ.get('SL7_OUT', str(Path(__file__).resolve().parents[1]))).resolve()
(OUT/'dataset/images').mkdir(parents=True, exist_ok=True)
(OUT/'generator').mkdir(parents=True, exist_ok=True)
(OUT/'eval').mkdir(parents=True, exist_ok=True)
(OUT/'results').mkdir(parents=True, exist_ok=True)

# Make renderer available locally. During first build, copy the frozen renderer from the prior package.
render_dst = OUT/'generator/render_style.py'
if not render_dst.exists():
    src = Path('/mnt/data/v14pkg_full/snakes-ladders-expansion-v14/generator/render_style.py')
    if not src.exists():
        src = Path('/mnt/data/snakes-ladders-discovery-v11/generator/render_style.py')
    shutil.copy2(src, render_dst)

sys.path.insert(0, str(OUT/'generator'))
import render_style as rs

# ---------- constants ----------
BLACK=(22,22,22); WHITE=(250,250,250); BLUE=(54,120,214); RED=(218,72,62)
GREEN=(52,158,108); PURPLE=(113,82,194); ORANGE=(230,126,55); PINK=(205,84,142); CYAN=(25,158,205)
COLORS=[RED,GREEN,PURPLE,ORANGE,BLUE,PINK]
FONT_PATH=rs.FONT_PATH
FONT_LABEL=ImageFont.truetype(FONT_PATH, 14)

# ---------- geometry ----------
def cell_for_square(n):
    row=(n-1)//10+1; off=(n-1)%10
    col=off+1 if row%2==1 else 10-off
    return (row,col)

def square_for_cell(cell): return rs.zz(*cell)

def snake_obj_cells(head_cell, tail_cell, color=RED, phase=0.4, name='snake'):
    return {'kind':'snake','high_cell':list(head_cell),'low_cell':list(tail_cell),'color':list(color),'phase':phase,
            'head_square':square_for_cell(head_cell),'tail_square':square_for_cell(tail_cell),'name':name}

def snake_obj(head, tail, color=RED, phase=0.4, name='snake'):
    return snake_obj_cells(cell_for_square(head),cell_for_square(tail),color,phase,name)

def ladder_obj_cells(foot_cell, top_cell, lean=0, name='ladder'):
    return {'kind':'ladder','low_cell':list(foot_cell),'high_cell':list(top_cell),'lean':lean,
            'foot_square':square_for_cell(foot_cell),'top_square':square_for_cell(top_cell),'name':name}

def ladder_obj(foot, top, lean=0, name='ladder'):
    return ladder_obj_cells(cell_for_square(foot),cell_for_square(top),lean,name)

def render(objects=None, hidden_rows=None, hidden_cells=None, star_cell=None, outline_cell=None):
    objects=objects or []
    hidden_rows=set(hidden_rows or [])
    hidden_cells=set(hidden_cells or [])
    im=rs.background(); d=ImageDraw.Draw(im)
    for o in objects:
        if o['kind']=='snake': rs.snake(d,tuple(o['high_cell']),tuple(o['low_cell']),tuple(o['color']),o.get('phase',0))
        else: rs.ladder(d,tuple(o['low_cell']),tuple(o['high_cell']),o.get('lean',0))
    if star_cell is not None: rs.star(d,star_cell)
    for row in range(1,11):
        for col in range(1,11):
            if row in hidden_rows or (row,col) in hidden_cells: continue
            x=(col-1)*rs.RCELL+rs.NUMBER_OFFSET[0]; y=(10-row)*rs.RCELL+rs.NUMBER_OFFSET[1]
            d.text((x,y),str(rs.zz(row,col)),font=rs.FONT_NUM,fill=rs.NUM,stroke_width=3*rs.S,stroke_fill=rs.cell_fill(row,col))
    if outline_cell is not None:
        rs.calibration_outline(d,outline_cell)
    return im.resize((1000,1000),Image.Resampling.LANCZOS)

def save_img(name, im):
    p=OUT/'dataset/images'/name; p.parent.mkdir(parents=True, exist_ok=True); im.save(p)
    return f'dataset/images/{name}'

def render_save(name, **kwargs): return save_img(name, render(**kwargs))

def draw_die(value, color='blue'):
    im=Image.new('RGB',(420,420),(248,248,248)); d=ImageDraw.Draw(im)
    fill=BLUE if color=='blue' else RED
    d.rounded_rectangle([55,55,365,365],radius=48,fill=fill,outline=(55,55,55),width=8)
    pos={1:[(210,210)],2:[(140,140),(280,280)],3:[(140,140),(210,210),(280,280)],4:[(140,140),(280,140),(140,280),(280,280)],5:[(140,140),(280,140),(210,210),(140,280),(280,280)],6:[(140,125),(280,125),(140,210),(280,210),(140,295),(280,295)]}
    for x,y in pos[value]: d.ellipse([x-18,y-18,x+18,y+18],fill=BLACK)
    return im

def object_path_cells(o):
    if o['kind']=='snake':
        pts=rs.curve(rs.center(*tuple(o['high_cell'])),rs.center(*tuple(o['low_cell'])),o.get('phase',0),n=180)
    else:
        x0,y0=rs.center(*tuple(o['low_cell'])); x1,y1=rs.center(*tuple(o['high_cell']))
        pts=[(x0+(x1-x0)*i/179,y0+(y1-y0)*i/179) for i in range(180)]
    cells=[]
    for x,y in pts:
        col=max(1,min(10,int(x//rs.RCELL)+1)); row=max(1,min(10,10-int(y//rs.RCELL)))
        c=(row,col)
        if c not in cells: cells.append(c)
    return cells

def choose_body_cell(o):
    cells=object_path_cells(o)
    endpoints={tuple(o['high_cell']),tuple(o['low_cell'])}
    candidates=[c for c in cells if c not in endpoints]
    if not candidates: raise ValueError('No body cell')
    return candidates[len(candidates)//2]

def choose_empty_near(o):
    occupied=set(object_path_cells(o)) | {tuple(o['high_cell']),tuple(o['low_cell'])}
    anchors=[tuple(o['high_cell']),tuple(o['low_cell'])]
    for a in anchors:
        r,c=a
        for dr,dc in [(0,1),(0,-1),(1,0),(-1,0),(1,1),(-1,-1)]:
            q=(r+dr,c+dc)
            if 1<=q[0]<=10 and 1<=q[1]<=10 and q not in occupied:
                return q
    raise ValueError('No nearby empty cell')

def replace_snake_tail(objects, head, new_tail):
    arr=json.loads(json.dumps(objects))
    for o in arr:
        if o['kind']=='snake' and o.get('head_square')==head:
            o['tail_square']=new_tail; o['low_cell']=list(cell_for_square(new_tail))
    return arr

def replace_ladder_top(objects, foot, new_top):
    arr=json.loads(json.dumps(objects))
    for o in arr:
        if o['kind']=='ladder' and o.get('foot_square')==foot:
            o['top_square']=new_top; o['high_cell']=list(cell_for_square(new_top))
    return arr

# ---------- rows ----------
FIELDS=['item_id','part','task_family','blindspot_hypothesis','role','scenario_id','matched_pair_id','image_paths','prompt','answer_format','correct_answer','predicted_error_values','predicted_error_label','metadata_json']
rows=[]
def add(item_id,part,family,hyp,role,scenario,image_paths,prompt,fmt,gold,pred='',pred_label='',pair='',meta=None):
    ip='|'.join(image_paths) if isinstance(image_paths,(list,tuple)) else image_paths
    rows.append(dict(item_id=item_id,part=part,task_family=family,blindspot_hypothesis=hyp,role=role,scenario_id=scenario,matched_pair_id=pair,
                     image_paths=ip,prompt=prompt,answer_format=fmt,correct_answer=str(gold),predicted_error_values=str(pred),predicted_error_label=pred_label,
                     metadata_json=json.dumps(meta or {},separators=(',',':'))))

boards={'generation_seed':GENERATION_SEED,'families':{}}

# ---------- Family B1 ----------
B1_OBJS=[snake_obj_cells((10,10),(7,10),GREEN,0.6,'filler_snake'), ladder_obj_cells((1,1),(4,1),0,'filler_ladder')]
b1_img=render_save('B1_base.png',objects=B1_OBJS)
# matched columns/nearby row bands
b1_pairs=[((1,2),(2,2)),((1,5),(2,5)),((3,3),(4,3)),((3,7),(4,7)),((5,2),(6,2)),((5,6),(6,6)),((7,4),(8,4)),((7,8),(8,8)),((9,3),(10,3)),((9,7),(10,7))]
boards['families']['B1']={'objects':B1_OBJS,'pairs':[]}
for i,(cc,pc) in enumerate(b1_pairs,1):
    ct=square_for_cell(cc); pt=square_for_cell(pc); cg=square_for_cell((cc[0],cc[1]+1)); pg=square_for_cell((pc[0],pc[1]+1)); pred=pt+1
    pair=f'B1_PAIR_{i:02d}'
    boards['families']['B1']['pairs'].append({'pair_id':pair,'control_target':ct,'probe_target':pt,'control_cell':cc,'probe_cell':pc})
    add(f'B1_C{i:02d}','SCORED','B1_zigzag_direction','Zig-zag direction-reversal failure','control',f'B1_{i}',b1_img,
        f'On this Snakes & Ladders board, what numbered square is immediately to the right of square {ct}, as you look at the image? Reply with one integer only.','integer',cg,pair=pair,meta={'target':ct,'cell':cc})
    add(f'B1_P{i:02d}','SCORED','B1_zigzag_direction','Zig-zag direction-reversal failure','probe',f'B1_{i}',b1_img,
        f'On this Snakes & Ladders board, what numbered square is immediately to the right of square {pt}, as you look at the image? Reply with one integer only.','integer',pg,pred,'right_equals_plus_one',pair,{'target':pt,'cell':pc})

# ---------- Family B2 ----------
B2_OBJS=[snake_obj_cells((10,1),(7,1),PURPLE,1.0,'filler_snake'), ladder_obj_cells((1,10),(4,10),0,'filler_ladder')]
b2_cells=[(2,4),(3,7),(4,5),(5,3),(6,8),(7,6),(8,4),(9,7),(3,2),(8,9)]
boards['families']['B2']={'objects':B2_OBJS,'targets':[]}
for i,cell in enumerate(b2_cells,1):
    target=square_for_cell(cell); row,col=cell; pair=f'B2_PAIR_{i:02d}'
    pv=[]
    # structural shortcuts, pre-registered
    if row<10: pv.append(square_for_cell((row+1,col)))
    if row>1: pv.append(square_for_cell((row-1,col)))
    # nearest horizontal visible neighbour (left, unless edge)
    nc=col-1 if col>1 else col+1
    pv.append(square_for_cell((row,nc)))
    typewriter=(row-1)*10+col
    pv.append(typewriter)
    pv=[x for j,x in enumerate(pv) if x!=target and x not in pv[:j]]
    pvis=render_save(f'B2_{i:02d}_visible.png',objects=B2_OBJS,star_cell=cell)
    phid=render_save(f'B2_{i:02d}_hidden.png',objects=B2_OBJS,star_cell=cell,hidden_rows=[row])
    boards['families']['B2']['targets'].append({'pair_id':pair,'target':target,'cell':cell,'shortcut_answers':pv})
    prompt='What number belongs in the cell marked with the blue star? Reply with one integer only.'
    add(f'B2_C{i:02d}','SCORED','B2_hidden_reconstruction','Hidden-board reconstruction failure','control',f'B2_{i}',pvis,prompt,'integer',target,pair=pair,meta={'target':target,'cell':cell,'mask':'visible'})
    add(f'B2_P{i:02d}','SCORED','B2_hidden_reconstruction','Hidden-board reconstruction failure','probe',f'B2_{i}',phid,prompt,'integer',target,'|'.join(map(str,pv)),'structural_shortcut',pair,{'target':target,'cell':cell,'mask':'row_hidden','shortcut_answers':pv})

# ---------- Family B3 ----------
boards['families']['B3']={'positive_controls':[],'absence_probes':[]}
# Positive controls: 3 heads, 3 tails, 2 feet, 2 tops
pos_objs=[
    (snake_obj(88,63,RED,0.2,'s1'),88,'snake head'),
    (snake_obj(95,74,GREEN,0.9,'s2'),95,'snake head'),
    (snake_obj(67,45,PURPLE,1.4,'s3'),67,'snake head'),
    (snake_obj(84,61,ORANGE,2.0,'s4'),61,'snake tail'),
    (snake_obj(93,72,BLUE,0.7,'s5'),72,'snake tail'),
    (snake_obj(76,52,PINK,1.8,'s6'),52,'snake tail'),
    (ladder_obj(12,34,0,'l1'),12,'ladder foot'),
    (ladder_obj(46,68,0,'l2'),46,'ladder foot'),
    (ladder_obj(15,37,0,'l3'),37,'ladder top'),
    (ladder_obj(43,65,0,'l4'),65,'ladder top'),
]
for i,(o,target,label) in enumerate(pos_objs,1):
    cell=cell_for_square(target); p=render_save(f'B3_C{i:02d}.png',objects=[o],outline_cell=cell)
    boards['families']['B3']['positive_controls'].append({'id':i,'object':o,'target':target,'label':label})
    add(f'B3_C{i:02d}','SCORED','B3_endpoint_anchoring','Endpoint anchoring / absence hallucination','control',f'B3C{i}',p,
        'What endpoint, if any, is anchored in the cell with the magenta outline? Reply with exactly one of: snake head, snake tail, ladder foot, ladder top, no endpoint.','label',label)
# 5 body-crossing probes
body_objs=[snake_obj(89,52,RED,0.3,'b1'),snake_obj(97,71,GREEN,1.1,'b2'),ladder_obj(16,48,0,'b3'),ladder_obj(33,65,0,'b4'),snake_obj(78,41,PURPLE,2.0,'b5')]
for j,o in enumerate(body_objs,1):
    cell=choose_body_cell(o); p=render_save(f'B3_P{j:02d}_body.png',objects=[o],outline_cell=cell)
    boards['families']['B3']['absence_probes'].append({'id':j,'kind':'body_crossing','object':o,'cell':cell,'square':square_for_cell(cell)})
    add(f'B3_P{j:02d}','SCORED','B3_endpoint_anchoring','Endpoint anchoring / absence hallucination','probe',f'B3P{j}',p,
        'What endpoint, if any, is anchored in the cell with the magenta outline? Reply with exactly one of: snake head, snake tail, ladder foot, ladder top, no endpoint.','label','no endpoint','snake head|snake tail|ladder foot|ladder top','positive_endpoint_hallucination',meta={'probe_kind':'body_crossing','cell':cell})
# 5 empty-near-object probes
empty_objs=[snake_obj(86,62,ORANGE,0.5,'e1'),ladder_obj(24,56,0,'e2'),snake_obj(92,73,BLUE,1.5,'e3'),ladder_obj(31,64,0,'e4'),snake_obj(75,43,PINK,2.3,'e5')]
for j,o in enumerate(empty_objs,6):
    cell=choose_empty_near(o); p=render_save(f'B3_P{j:02d}_empty.png',objects=[o],outline_cell=cell)
    boards['families']['B3']['absence_probes'].append({'id':j,'kind':'empty_near_object','object':o,'cell':cell,'square':square_for_cell(cell)})
    add(f'B3_P{j:02d}','SCORED','B3_endpoint_anchoring','Endpoint anchoring / absence hallucination','probe',f'B3P{j}',p,
        'What endpoint, if any, is anchored in the cell with the magenta outline? Reply with exactly one of: snake head, snake tail, ladder foot, ladder top, no endpoint.','label','no endpoint','snake head|snake tail|ladder foot|ladder top','positive_endpoint_hallucination',meta={'probe_kind':'empty_near_object','cell':cell})

# ---------- Family B4 ----------
b4_scen=[
 ('snake',96,64,RED,0.2),('snake',86,53,GREEN,0.8),('snake',75,42,PURPLE,1.5),('snake',68,31,ORANGE,2.1),('snake',57,24,BLUE,0.5),
 ('ladder',13,36,None,0),('ladder',22,45,None,0),('ladder',34,58,None,0),('ladder',41,73,None,0),('ladder',52,84,None,0)
]
boards['families']['B4']={'scenarios':[]}
for i,(kind,start,dest,color,phase) in enumerate(b4_scen,1):
    if kind=='snake': o=snake_obj(start,dest,color,phase,f'b4s{i}'); endpoint='snake head'; relation='snake'; verb='snake head'; destname='tail'
    else: o=ladder_obj(start,dest,0,f'b4l{i}'); endpoint='ladder foot'; relation='ladder'; verb='ladder foot'; destname='top'
    cell=cell_for_square(start); p=render_save(f'B4_{i:02d}.png',objects=[o],outline_cell=cell)
    sid=f'B4_{i:02d}'; pair=f'B4_PAIR_{i:02d}'
    cid=f'B4_C{i:02d}'; pid=f'B4_P{i:02d}'
    boards['families']['B4']['scenarios'].append({'scenario':sid,'object':o,'landing':start,'destination':dest})
    add(cid,'SCORED','B4_perception_to_action','Perception-to-action transport gap','prerequisite',sid,p,
        f'The magenta-outlined square contains this {verb}. What numbered square is the {destname} of the same {relation}? Reply with one integer only.','integer',dest,pair=pair,meta={'landing':start,'destination':dest,'object_kind':kind})
    add(pid,'SCORED','B4_perception_to_action','Perception-to-action transport gap','probe',sid,p,
        f'A token lands on square {start}. Apply the normal Snakes & Ladders rule. What square does the token finally stop on? Reply with one integer only.','integer',dest,start,'stayed_on_landing_square',pair,{'prerequisite_ids':[cid],'landing':start,'destination':dest,'object_kind':kind})

# ---------- Family B5 ----------
# Each scenario contains the relevant object plus one distant filler. Two obvious + eight subtle.
b5_defs=[
 ('snake',87,62,22,'obvious'),('ladder',23,45,85,'obvious'),
 ('snake',89,54,56,'subtle'),('ladder',26,63,65,'subtle'),('snake',78,43,41,'subtle'),('ladder',32,57,59,'subtle'),
 ('snake',96,71,73,'subtle'),('ladder',44,66,68,'subtle'),('snake',85,52,50,'subtle'),('ladder',18,39,37,'subtle')
]
boards['families']['B5']={'scenarios':[]}
for i,(kind,anchor,d1,d2,diff) in enumerate(b5_defs,1):
    # balance which identity board has higher destination: odd i identity X uses d1, even i identity X uses d2
    if kind=='snake':
        filler=ladder_obj(11,31,0,'filler') if anchor>50 else snake_obj(94,72,GREEN,1.0,'filler')
        ox=snake_obj(anchor,d1,RED,0.4,f'relevant'); oy=snake_obj(anchor,d2,RED,0.4,f'relevant')
    else:
        filler=snake_obj(93,71,GREEN,1.0,'filler') if anchor<50 else ladder_obj(12,34,0,'filler')
        ox=ladder_obj(anchor,d1,0,'relevant'); oy=ladder_obj(anchor,d2,0,'relevant')
    # To balance gold labels, swap identity destinations on even scenarios.
    if i%2==0: ox,oy=oy,ox; xdest,ydest=d2,d1
    else: xdest,ydest=d1,d2
    xobjs=[filler,ox]; yobjs=[filler,oy]
    cell=cell_for_square(anchor)
    px=render_save(f'B5_{i:02d}_X.png',objects=xobjs,outline_cell=cell); py=render_save(f'B5_{i:02d}_Y.png',objects=yobjs,outline_cell=cell)
    sid=f'B5_{i:02d}'
    base_gold='A' if xdest>ydest else 'B'; swap_gold='B' if base_gold=='A' else 'A'
    role='control' if diff=='obvious' else 'probe'
    prompt=f'Image A is the first board and Image B is the second. A token lands on square {anchor} in both boards. After applying the magenta-highlighted {kind}, in which board does the token finish on the HIGHER numbered square? Reply with exactly A or B.'
    add(f'B5_{"C" if role=="control" else "P"}{i:02d}a','SCORED','B5_multi_image_position','Subtle multi-image positional shortcut',role,sid,[px,py],prompt,'choice_ab',base_gold,pair=f'{sid}_ORDERPAIR',meta={'order':'XY','identity_destinations':{'X':xdest,'Y':ydest},'difficulty':diff})
    add(f'B5_{"C" if role=="control" else "P"}{i:02d}b','SCORED','B5_multi_image_position','Subtle multi-image positional shortcut',role,sid,[py,px],prompt,'choice_ab',swap_gold,pair=f'{sid}_ORDERPAIR',meta={'order':'YX','identity_destinations':{'X':xdest,'Y':ydest},'difficulty':diff})
    boards['families']['B5']['scenarios'].append({'scenario':sid,'kind':kind,'anchor':anchor,'X_destination':xdest,'Y_destination':ydest,'difficulty':diff,'gold_original':base_gold,'gold_swapped':swap_gold})

# ---------- Family B6 ----------
def snake_board(head_cells):
    objs=[]
    for j,h in enumerate(head_cells):
        tail=(max(1,h[0]-3),h[1])
        objs.append(snake_obj_cells(h,tail,COLORS[j%len(COLORS)],0.4+0.55*j,f's{j+1}'))
    return objs

def ladder_board(foot_cells):
    objs=[]
    for j,f in enumerate(foot_cells):
        top=(min(10,f[0]+3),f[1])
        objs.append(ladder_obj_cells(f,top,0,f'l{j+1}'))
    return objs

b6_cfg=[
 ('snake',[(8,2),(9,7)],'gt',80),
 ('snake',[(7,1),(8,5),(9,9)],'even',None),
 ('snake',[(6,2),(7,4),(8,6),(9,8)],'gt',70),
 ('snake',[(6,1),(7,3),(8,5),(9,7),(10,9)],'odd',None),
 ('snake',[(7,2),(8,8),(9,5)],'even',None),
 ('ladder',[(2,2),(3,7)],'lt',20),
 ('ladder',[(2,3),(3,5),(4,8)],'odd',None),
 ('ladder',[(2,4),(3,2),(4,6),(5,8)],'lt',30),
 ('ladder',[(2,5),(3,3),(4,4),(5,7),(6,9)],'odd',None),
 ('ladder',[(3,4),(4,7),(5,2)],'lt',40),
]
boards['families']['B6']={'scenarios':[]}
for i,(kind,cells,cond,thr) in enumerate(b6_cfg,1):
    objs=snake_board(cells) if kind=='snake' else ladder_board(cells)
    values=[o['head_square'] if kind=='snake' else o['foot_square'] for o in objs]
    total=len(values)
    if cond=='gt': filt=[v for v in values if v>thr]; phrase=f'on squares greater than {thr}'
    elif cond=='lt': filt=[v for v in values if v<thr]; phrase=f'on squares below {thr}'
    elif cond=='even': filt=[v for v in values if v%2==0]; phrase='on even-numbered squares'
    elif cond=='odd': filt=[v for v in values if v%2==1]; phrase='on odd-numbered squares'
    gold=len(filt)
    if not (0<gold<total): raise ValueError(('B6 bad filter',i,values,cond,thr,gold,total))
    p=render_save(f'B6_{i:02d}.png',objects=objs); pair=f'B6_PAIR_{i:02d}'; noun='snakes' if kind=='snake' else 'ladders'; endpoint='snake heads' if kind=='snake' else 'ladder feet'
    add(f'B6_C{i:02d}','SCORED','B6_conditioned_counting','Attribute-conditioned visual counting failure','control',f'B6_{i}',p,f'How many {noun} are on the board? Reply with one integer only.','integer',total,pair=pair,meta={'total':total,'values':values})
    add(f'B6_P{i:02d}','SCORED','B6_conditioned_counting','Attribute-conditioned visual counting failure','probe',f'B6_{i}',p,f'How many {endpoint} are {phrase}? Reply with one integer only.','integer',gold,total,'returned_unfiltered_total',pair,{'total':total,'values':values,'filter':phrase,'filtered_values':filt})
    boards['families']['B6']['scenarios'].append({'scenario':i,'kind':kind,'values':values,'filter':phrase,'gold':gold,'total':total})

# ---------- Family B7 ----------
b7_board=render_save('B7_plain_board.png',objects=[])
b7_defs=[(1,2,3),(4,1,4),(21,2,4),(24,1,5),(43,3,4),(44,2,3),(61,1,6),(64,2,4),(81,3,5),(84,2,4)]
boards['families']['B7']={'scenarios':[]}
for i,(start,a,b) in enumerate(b7_defs,1):
    # start and result stay in same odd row; thus movement is visually simple and has no object effects
    gold=start+a+b; sr=(start-1)//10+1; gr=(gold-1)//10+1
    if sr!=gr or sr%2==0: raise ValueError(('B7 row contamination',i,start,a,b,gold))
    pa=save_img(f'B7_{i:02d}_A.png',draw_die(a,'blue')); pb=save_img(f'B7_{i:02d}_B.png',draw_die(b,'red'))
    sid=f'B7_{i:02d}'; ca=f'B7_C{i:02d}a'; cb=f'B7_C{i:02d}b'; pp=f'B7_P{i:02d}'
    add(ca,'SCORED','B7_multi_source_composition','Multi-source visual composition failure','prerequisite',sid,pa,'How many pips are shown on this die? Reply with one integer only.','integer',a)
    add(cb,'SCORED','B7_multi_source_composition','Multi-source visual composition failure','prerequisite',sid,pb,'How many pips are shown on this die? Reply with one integer only.','integer',b)
    vals=[]
    for v in [start+a,start+b]:
        if v!=gold and v not in vals: vals.append(v)
    add(pp,'SCORED','B7_multi_source_composition','Multi-source visual composition failure','probe',sid,[b7_board,pa,pb],
        f'The token starts on square {start}. Add the values shown on BOTH dice, then move forward by that total. What square does the token finish on? Reply with one integer only.','integer',gold,'|'.join(map(str,vals)),'used_only_one_die',meta={'prerequisite_ids':[ca,cb],'start':start,'die_A':a,'die_B':b,'only_A_answer':start+a,'only_B_answer':start+b,'sum':a+b})
    boards['families']['B7']['scenarios'].append({'scenario':sid,'start':start,'die_A':a,'die_B':b,'gold':gold})

# ---------- Calibration ----------
boards['calibration']={}
# 8 number reading items, separate plain calibration images
cal_num_cells=[(1,7),(2,6),(3,4),(4,8),(5,5),(6,3),(8,7),(10,4)]
for i,cell in enumerate(cal_num_cells,1):
    p=render_save(f'CAL_NUM_{i:02d}.png',objects=[],outline_cell=cell); gold=square_for_cell(cell)
    add(f'CAL_NUM_{i:02d}','CAL','CAL_number','', 'calibration',f'CALN{i}',p,'What number is written in the magenta-outlined cell? Reply with one integer only.','integer',gold)
# 4 endpoint recognition isolated objects
cal_eps=[(snake_obj(91,71,RED,0.4,'cal_s1'),91,'snake head'),(snake_obj(83,62,GREEN,1.2,'cal_s2'),62,'snake tail'),(ladder_obj(17,49,0,'cal_l1'),17,'ladder foot'),(ladder_obj(35,77,0,'cal_l2'),77,'ladder top')]
for i,(o,target,gold) in enumerate(cal_eps,1):
    p=render_save(f'CAL_END_{i:02d}.png',objects=[o],outline_cell=cell_for_square(target))
    add(f'CAL_END_{i:02d}','CAL','CAL_endpoint','', 'calibration',f'CALE{i}',p,'What endpoint is anchored in the magenta-outlined cell? Reply with exactly one of: snake head, snake tail, ladder foot, ladder top.','label',gold)
# 4 die calibration
for i,(v,c) in enumerate([(1,'blue'),(4,'red'),(6,'blue'),(3,'red')],1):
    p=save_img(f'CAL_DIE_{i:02d}.png',draw_die(v,c)); add(f'CAL_DIE_{i:02d}','CAL','CAL_die','', 'calibration',f'CALD{i}',p,'How many pips are shown on this die? Reply with one integer only.','integer',v)
# 4 obvious two-image ordering items = two scenarios, each tested in both orders
cal_cmp=[((2,4),(8,7)),((3,8),(9,3))]
for s,(c1,c2) in enumerate(cal_cmp,1):
    p1=render_save(f'CAL_CMP_{s}_X.png',objects=[],star_cell=c1); p2=render_save(f'CAL_CMP_{s}_Y.png',objects=[],star_cell=c2)
    x=square_for_cell(c1); y=square_for_cell(c2); base='A' if x>y else 'B'; swap='B' if base=='A' else 'A'
    prompt='Image A is the first board and Image B is the second. In which board is the blue star on the HIGHER numbered square? Reply with exactly A or B.'
    add(f'CAL_CMP_{2*s-1:02d}','CAL','CAL_multi_image','', 'calibration',f'CALCMP{s}',[p1,p2],prompt,'choice_ab',base)
    add(f'CAL_CMP_{2*s:02d}','CAL','CAL_multi_image','', 'calibration',f'CALCMP{s}',[p2,p1],prompt,'choice_ab',swap)

# ---------- write dataset ----------
# stable order: calibration first, then scored families B1..B7. Within scored, current generation order already B1..B7.
cal=[r for r in rows if r['part']=='CAL']; scored=[r for r in rows if r['part']=='SCORED']; rows_ordered=cal+scored
if len(cal)!=20 or len(scored)!=150: raise AssertionError((len(cal),len(scored),len(rows_ordered)))
with open(OUT/'dataset/items.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=FIELDS); w.writeheader(); w.writerows(rows_ordered)
with open(OUT/'dataset/calibration_items.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=FIELDS); w.writeheader(); w.writerows(cal)
with open(OUT/'dataset/scored_items.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=FIELDS); w.writeheader(); w.writerows(scored)
(OUT/'dataset/boards.json').write_text(json.dumps(boards,indent=2),encoding='utf-8')

# ---------- score.py ----------
score_py=r'''import csv,re,json,math
from pathlib import Path
from collections import defaultdict,Counter
LABELS=['snake head','snake tail','ladder foot','ladder top','no endpoint']

def parse_strict(raw,fmt):
    s=(raw or '').strip().lower()
    if fmt=='integer':
        nums=re.findall(r'(?<!\d)(100|[1-9]?\d)(?!\d)',s)
        return nums[0] if len(nums)==1 else ''
    if fmt=='choice_ab':
        hits=re.findall(r'\b([ab])\b',s)
        return hits[0].upper() if len(hits)==1 else ''
    if fmt=='label':
        hits=[x for x in LABELS if x in s]
        return hits[0] if len(hits)==1 else ''
    return s

def wilson(k,n,z=1.959963984540054):
    if n==0:return ('','')
    p=k/n; den=1+z*z/n; ctr=(p+z*z/(2*n))/den; half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return (max(0,ctr-half),min(1,ctr+half))

def pct(k,n): return 100*k/n if n else float('nan')

def exact_mcnemar(pairs):
    # pairs are tuples (control_correct, probe_correct)
    b=sum(1 for c,p in pairs if c and not p); c=sum(1 for c0,p in pairs if (not c0) and p); n=b+c
    if n==0:return (b,c,1.0)
    m=min(b,c); tail=sum(math.comb(n,k) for k in range(0,m+1))/(2**n); return (b,c,min(1.0,2*tail))

def score(items_csv,raw_csv,out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    items=list(csv.DictReader(open(items_csv,encoding='utf-8')))
    rawrows=list(csv.DictReader(open(raw_csv,encoding='utf-8')))
    preds={r['item_id']:r.get('raw_output','') for r in rawrows}
    rows=[]
    for it in items:
        raw=preds.get(it['item_id'],''); parsed=parse_strict(raw,it['answer_format']); gold=it['correct_answer'].strip().lower()
        ok=bool(parsed) and parsed.lower()==gold
        predset=[x.strip().lower() for x in it.get('predicted_error_values','').split('|') if x.strip()]
        sig=(not ok) and bool(parsed) and parsed.lower() in predset
        md=json.loads(it.get('metadata_json') or '{}')
        rows.append({**it,'raw_output':raw,'parsed_answer':parsed,'correct':int(ok),'matches_predicted_error':int(sig),'missing':int(it['item_id'] not in preds),'metadata':md})
    byid={r['item_id']:r for r in rows}
    for r in rows:
        pre=r['metadata'].get('prerequisite_ids',[]); r['prerequisites_pass']=int(all(byid.get(x,{}).get('correct',0)==1 for x in pre)) if pre else 1
    # write scored.csv without embedded metadata dict
    export=[]
    for r in rows:
        q=dict(r); q.pop('metadata',None); export.append(q)
    with open(out/'scored.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(export[0].keys())); w.writeheader(); w.writerows(export)

    cal=[r for r in rows if r['part']=='CAL']; scored=[r for r in rows if r['part']=='SCORED']
    calgroups=defaultdict(list)
    for r in cal: calgroups[r['task_family']].append(r)
    cal_summary={k:(sum(x['correct'] for x in v),len(v)) for k,v in calgroups.items()}

    fam=defaultdict(list)
    for r in scored:fam[r['task_family']].append(r)
    family_rows=[]; details={}
    def common(name,control_roles=('control',),probe_roles=('probe',)):
        rr=fam[name]; ctr=[r for r in rr if r['role'] in control_roles]; pro=[r for r in rr if r['role'] in probe_roles]
        ck=sum(r['correct'] for r in ctr); pk=sum(r['correct'] for r in pro); errs=[r for r in pro if not r['correct']]; sig=sum(r['matches_predicted_error'] for r in errs)
        gap=(ck/len(ctr)-pk/len(pro)) if ctr and pro else float('nan')
        return rr,ctr,pro,ck,pk,errs,sig,gap

    # B1
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B1_zigzag_direction')
    status=(ck>=8 and pk<=5 and gap>=.30 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='control'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B1_zigzag_direction']={'mcnemar':(mb,mc,mp)}
    family_rows.append(('B1_zigzag_direction',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,mp,'control>=8/10; probe<=5/10; gap>=30pp; >=60% probe errors = T+1'))

    # B2
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B2_hidden_reconstruction')
    status=(ck>=9 and pk<=5 and gap>=.40 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='control'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B2_hidden_reconstruction']={'mcnemar':(mb,mc,mp)}
    family_rows.append(('B2_hidden_reconstruction',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,mp,'control>=9/10; probe<=5/10; gap>=40pp; >=60% errors structural shortcuts'))

    # B3
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B3_endpoint_anchoring')
    status=(ck>=8 and pk<=5 and (sig/len(errs) if errs else 0)>=.60)
    family_rows.append(('B3_endpoint_anchoring',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,'','positive endpoints>=8/10; absence<=5/10; >=60% errors hallucinate endpoint'))

    # B4 prerequisite + eligible probes
    rr=fam['B4_perception_to_action']; ctr=[r for r in rr if r['role']=='prerequisite']; pro=[r for r in rr if r['role']=='probe']; elig=[r for r in pro if r['prerequisites_pass']]
    ck=sum(r['correct'] for r in ctr); pk=sum(r['correct'] for r in elig); errs=[r for r in elig if not r['correct']]; sig=sum(r['matches_predicted_error'] for r in errs); gap=ck/len(ctr)-(pk/len(elig) if elig else 0)
    status=(ck>=8 and len(elig)>=8 and (pk/len(elig) if elig else 1)<=.50 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='prerequisite'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B4_perception_to_action']={'mcnemar':(mb,mc,mp),'snake':{},'ladder':{}}
    for kind in ('snake','ladder'):
        aa=[r for r in pro if r['prerequisites_pass'] and r['metadata'].get('object_kind')==kind]; details['B4_perception_to_action'][kind]={'correct':sum(r['correct'] for r in aa),'n':len(aa)}
    family_rows.append(('B4_perception_to_action',ck,len(ctr),pk,len(elig),len(elig),sig,len(errs),gap,status,mp,'destination>=8/10; eligible action<=50%; >=60% eligible errors stay on landing'))

    # B5
    rr=fam['B5_multi_image_position']; ctr=[r for r in rr if r['role']=='control']; pro=[r for r in rr if r['role']=='probe']; ck=sum(r['correct'] for r in ctr); pk=sum(r['correct'] for r in pro); errs=[r for r in pro if not r['correct']]
    scenario=defaultdict(list)
    for r in pro: scenario[r['scenario_id']].append(r)
    locked=0; lock_n=0
    for sid,v in scenario.items():
        if len(v)==2 and all(x['parsed_answer'] in {'A','B'} for x in v): lock_n+=1; locked+=int(v[0]['parsed_answer']==v[1]['parsed_answer'])
    status=(ck>=3 and pk<=8 and locked>=5)
    bias=Counter(r['parsed_answer'] for r in pro if r['parsed_answer'] in {'A','B'})
    gap=ck/len(ctr)-pk/len(pro)
    details['B5_multi_image_position']={'position_locked':locked,'position_lock_n':lock_n,'A_responses':bias.get('A',0),'B_responses':bias.get('B',0)}
    family_rows.append(('B5_multi_image_position',ck,len(ctr),pk,len(pro),len(pro),'',len(errs),gap,status,'',f'obvious>=3/4; subtle<=8/16; position-lock>=5/8 (observed {locked}/{lock_n})'))

    # B6
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B6_conditioned_counting')
    status=(ck>=8 and pk<=5 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='control'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B6_conditioned_counting']={'mcnemar':(mb,mc,mp)}
    family_rows.append(('B6_conditioned_counting',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,mp,'total>=8/10; filtered<=5/10; >=60% errors return total'))

    # B7
    rr=fam['B7_multi_source_composition']; ctr=[r for r in rr if r['role']=='prerequisite']; pro=[r for r in rr if r['role']=='probe']; ck=sum(r['correct'] for r in ctr); elig=[r for r in pro if r['prerequisites_pass']]; pk=sum(r['correct'] for r in elig)
    errs=[r for r in elig if not r['correct']]; sig=sum(r['matches_predicted_error'] for r in errs); comp_acc=ck/len(ctr); probe_acc=pk/len(elig) if elig else 1; gap=comp_acc-probe_acc
    status=(len(elig)>=8 and probe_acc<=.50 and gap>=.40)
    cats=Counter()
    for r in errs:
        val=r['parsed_answer']; md=r['metadata'];
        if val and val==str(md.get('only_A_answer')): cats['only_A']+=1
        elif val and val==str(md.get('only_B_answer')): cats['only_B']+=1
        elif val: cats['wrong_arithmetic_or_other']+=1
        else: cats['unparsed']+=1
    details['B7_multi_source_composition']={'eligible_scenarios':len(elig),'error_categories':dict(cats)}
    family_rows.append(('B7_multi_source_composition',ck,len(ctr),pk,len(elig),len(elig),sig,len(errs),gap,status,'','>=8/10 scenarios both components correct; eligible composition<=50%; component-composition gap>=40pp'))

    # summary CSV
    fh=['family','control_or_component_correct','control_or_component_n','probe_correct','probe_n','eligible_probe_n','signature_matches','probe_errors','gap_percentage_points','confirmed','mcnemar_exact_p','criteria']
    with open(out/'family_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(fh)
        for x in family_rows:
            name,ck,cn,pk,pn,en,sig,errn,gap,status,mp,criteria=x; w.writerow([name,ck,cn,pk,pn,en,sig,errn,round(100*gap,1),int(status),mp,criteria])

    # Markdown summary
    L=['# SL-7 Final Holdout Summary','',f'Total scored: {len(scored)} | Calibration: {len(cal)}','', '## Calibration gates','', '| Calibration | Correct | Gate |','|---|---:|---|']
    gates={'CAL_number':(7,8),'CAL_endpoint':(3,4),'CAL_die':(4,4),'CAL_multi_image':(3,4)}
    calibration_pass=True
    for name in ['CAL_number','CAL_endpoint','CAL_die','CAL_multi_image']:
        k,n=cal_summary.get(name,(0,0)); need=gates[name][0]; ok=k>=need; calibration_pass &= ok; L.append(f'| {name.replace("CAL_","")} | {k}/{n} | {"PASS" if ok else "FAIL"} |')
    L += ['',f'**Overall calibration gate:** {"PASS" if calibration_pass else "FAIL"}','', '## Seven frozen hypotheses','', '| Family | Control/component | Probe | Gap | Signature | Confirmed | 95% CI control | 95% CI probe |','|---|---:|---:|---:|---:|---|---|---|']
    for x in family_rows:
        name,ck,cn,pk,pn,en,sig,errn,gap,status,mp,criteria=x; clo=wilson(ck,cn); plo=wilson(pk,pn)
        sigtxt=(f'{sig}/{errn}' if isinstance(sig,int) and errn else ('N/A' if sig=='' else str(sig)))
        L.append(f'| {name} | {ck}/{cn} | {pk}/{pn} | {100*gap:.1f} pp | {sigtxt} | **{"YES" if status else "NO"}** | {clo[0]*100:.1f}–{clo[1]*100:.1f}% | {plo[0]*100:.1f}–{plo[1]*100:.1f}% |')
    L += ['', '## Family-specific diagnostics','']
    b5=details['B5_multi_image_position']; L.append(f"- **B5 position-lock:** {b5['position_locked']}/{b5['position_lock_n']} subtle scenarios; A responses {b5['A_responses']}, B responses {b5['B_responses']} across subtle probes.")
    b7=details['B7_multi_source_composition']; L.append(f"- **B7 eligible composition scenarios:** {b7['eligible_scenarios']}/10; error categories: {b7['error_categories']}.")
    b4=details['B4_perception_to_action']; L.append(f"- **B4 eligible snake actions:** {b4['snake'].get('correct',0)}/{b4['snake'].get('n',0)} correct; ladder actions: {b4['ladder'].get('correct',0)}/{b4['ladder'].get('n',0)} correct.")
    L += ['', '## Interpretation policy','', 'These seven families were frozen before this run. A family is counted in the final blind-spot claim only if its pre-registered confirmation rule is satisfied on this holdout. No new blind-spot family should be introduced from these results.', '', '## Per-item failures','']
    for r in scored:
        if not r['correct']:
            elig='eligible' if r['prerequisites_pass'] else 'NOT eligible (prerequisite failed)'; tag='predicted signature' if r['matches_predicted_error'] else 'other error'
            L.append(f"- `{r['item_id']}` ({r['task_family']}, {r['role']}, {elig}): gold `{r['correct_answer']}`, model `{r['parsed_answer'] or r['raw_output']}`, {tag}.")
    (out/'summary.md').write_text('\n'.join(L)+'\n',encoding='utf-8')
    (out/'details.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
    return rows,family_rows,calibration_pass
'''
(OUT/'eval/score.py').write_text(score_py,encoding='utf-8')

# ---------- Kaggle notebook ----------
import json as J
def md(s): return {'cell_type':'markdown','metadata':{},'source':s.splitlines(keepends=True)}
def code(s): return {'cell_type':'code','execution_count':None,'metadata':{},'outputs':[],'source':s.splitlines(keepends=True)}
nbcells=[]
nbcells.append(md('''# SL-7 Final Holdout v16\n\n**Frozen final experiment.** Seven pre-registered blind-spot hypotheses, 20 calibration items, and 150 scored multimodal items.\n\nDo not edit prompts, answer keys, thresholds, or images after inspecting model outputs.'''))
nbcells.append(code('!pip install -q -U "transformers==5.17.0" "accelerate>=1.0"'))
nbcells.append(code('''import os,glob,csv,json,time,platform,sys,zipfile,importlib,random\nfrom pathlib import Path\nfrom PIL import Image\nimport torch, transformers\nMODEL_ID="Qwen/Qwen3-VL-4B-Instruct"\nMAX_NEW_TOKENS=64\nINFERENCE_SEED=20261004\nrandom.seed(INFERENCE_SEED); torch.manual_seed(INFERENCE_SEED)\n\nhits=[]\nfor p in glob.glob("/kaggle/input/**/dataset/items.csv",recursive=True):\n    root=Path(p).parent.parent\n    if (root/"VERSION_SL7_v16.txt").exists() and (root/"eval/score.py").exists(): hits.append(root)\nif not hits: raise FileNotFoundError("Add the snakes-ladders-SL7-final-v16 package as a Kaggle input dataset.")\nROOT=hits[0]; ITEMS=list(csv.DictReader(open(ROOT/"dataset/items.csv",encoding="utf-8")))\nCAL=[x for x in ITEMS if x["part"]=="CAL"]; SCORED=[x for x in ITEMS if x["part"]=="SCORED"]\nprint("Project root:",ROOT); print("Calibration:",len(CAL),"Scored:",len(SCORED))\nOUT=Path("/kaggle/working/results_SL7_final_v16"); OUT.mkdir(exist_ok=True)\nsys.path.insert(0,str(ROOT/"eval")); import score; importlib.reload(score)'''))
nbcells.append(code('''try:\n    from transformers import Qwen3VLForConditionalGeneration as ModelClass\nexcept ImportError:\n    from transformers import AutoModelForImageTextToText as ModelClass\nfrom transformers import AutoProcessor\nif not torch.cuda.is_available(): raise RuntimeError("Enable a Kaggle GPU accelerator.")\ntry:\n    model=ModelClass.from_pretrained(MODEL_ID,dtype=torch.float16,device_map={"":0},attn_implementation="sdpa")\nexcept TypeError:\n    model=ModelClass.from_pretrained(MODEL_ID,torch_dtype=torch.float16,device_map={"":0},attn_implementation="sdpa")\nmodel.eval(); processor=AutoProcessor.from_pretrained(MODEL_ID)\nenv={"model_id":MODEL_ID,"parameters":sum(p.numel() for p in model.parameters()),"transformers":transformers.__version__,"torch":torch.__version__,"cuda":torch.version.cuda,"gpu":torch.cuda.get_device_name(0),"python":platform.python_version(),"dtype":"float16","attention":"sdpa","decoding":"greedy","max_new_tokens":MAX_NEW_TOKENS,"inference_seed":INFERENCE_SEED,"generation_seed":20261004}\n(OUT/"environment.json").write_text(json.dumps(env,indent=2)); print(json.dumps(env,indent=2))'''))
nbcells.append(code('''RAW=OUT/"raw_outputs.csv"\noutrows=[]\ndef run_item(it):\n    images=[]; content=[]\n    for rel in [p for p in it["image_paths"].split("|") if p]:\n        with Image.open(ROOT/rel) as im: images.append(im.convert("RGB").copy())\n        content.append({"type":"image"})\n    content.append({"type":"text","text":it["prompt"]})\n    messages=[{"role":"user","content":content}]\n    prompt=processor.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)\n    inputs=processor(text=[prompt],images=images,return_tensors="pt").to(model.device)\n    if "pixel_values" in inputs: inputs["pixel_values"]=inputs["pixel_values"].to(torch.float16)\n    t0=time.time()\n    with torch.inference_mode(): generated=model.generate(**inputs,max_new_tokens=MAX_NEW_TOKENS,do_sample=False)\n    new=generated[:,inputs["input_ids"].shape[1]:]\n    reply=processor.batch_decode(new,skip_special_tokens=True,clean_up_tokenization_spaces=False)[0].strip()\n    return {"item_id":it["item_id"],"raw_output":reply,"seconds":round(time.time()-t0,2)}\n\ndef save_raw():\n    with open(RAW,"w",newline="",encoding="utf-8") as f:\n        w=csv.DictWriter(f,fieldnames=["item_id","raw_output","seconds"]); w.writeheader(); w.writerows(outrows)\n\n# CALIBRATION FIRST\nfor idx,it in enumerate(CAL,1):\n    outrows.append(run_item(it)); save_raw(); print(f"CAL {idx}/{len(CAL)}",it["item_id"])\n\n# Check frozen visual-legibility gates before the scored run.\npred={r["item_id"]:r["raw_output"] for r in outrows}\ngroups={}\nfor it in CAL:\n    parsed=score.parse_strict(pred[it["item_id"]],it["answer_format"]); ok=parsed.lower()==it["correct_answer"].lower() if parsed else False\n    groups.setdefault(it["task_family"],[]).append(ok)\nprint({k:(sum(v),len(v)) for k,v in groups.items()})\nrequirements={"CAL_number":7,"CAL_endpoint":3,"CAL_die":4,"CAL_multi_image":3}\nfailed=[k for k,need in requirements.items() if sum(groups.get(k,[]))<need]\nif failed:\n    raise RuntimeError(f"Calibration gate failed for {failed}. Do NOT run the scored holdout until visual legibility is fixed without looking at scored outputs.")\nprint("Calibration gate PASSED. Starting frozen scored holdout.")'''))
nbcells.append(code('''for idx,it in enumerate(SCORED,1):\n    outrows.append(run_item(it)); save_raw()\n    if idx%10==0 or idx==len(SCORED): print(f"SCORED {idx}/{len(SCORED)} complete")\nprint("Raw outputs saved:",RAW)'''))
nbcells.append(code('''scored_rows,family_rows,cal_pass=score.score(ROOT/"dataset/items.csv",RAW,OUT)\nprint((OUT/"summary.md").read_text())'''))
nbcells.append(code('''zip_path=Path("/kaggle/working/results_SL7_final_v16.zip")\nwith zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as z:\n    for p in OUT.rglob("*"):\n        if p.is_file(): z.write(p,arcname=p.name)\nprint("Download:",zip_path)'''))
nb={'cells':nbcells,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.11'}},'nbformat':4,'nbformat_minor':5}
(OUT/'eval/run_final_v16.ipynb').write_text(J.dumps(nb),encoding='utf-8')
# convenient top-level copy
shutil.copy2(OUT/'eval/run_final_v16.ipynb', OUT/'run_final_v16.ipynb')

# ---------- README / design / version ----------
# Copy frozen design if available.
design_src=Path('/mnt/data/SL7_FINAL_EXPERIMENT_DESIGN_v16.md')
if design_src.exists(): shutil.copy2(design_src, OUT/'FINAL_EXPERIMENT_DESIGN.md')
(OUT/'VERSION_SL7_v16.txt').write_text('SL-7 final holdout v16\nGeneration seed: 20261004\n',encoding='utf-8')
readme='''# SL-7 Final Holdout v16\n\n**Can a VLM Actually Play Snakes & Ladders? A Seven-Blind-Spot Multimodal Stress Test of Qwen3-VL-4B-Instruct**\n\nThis is the frozen final holdout benchmark. v9–v15 were discovery runs; headline quantitative claims should come from this package only.\n\n## Frozen hypotheses\n1. Zig-zag direction reversal\n2. Hidden-board reconstruction\n3. Endpoint anchoring / absence hallucination\n4. Perception-to-action transport gap\n5. Subtle multi-image positional shortcut\n6. Attribute-conditioned visual counting\n7. Multi-source visual composition\n\n## Size\n- 20 calibration items\n- 150 scored items\n- 170 total model queries\n\n## Run on Kaggle\n1. Upload the whole package as a Kaggle input dataset.\n2. Open `run_final_v16.ipynb` (or `eval/run_final_v16.ipynb`).\n3. Enable a GPU accelerator.\n4. Run all cells without changing prompts, thresholds, images, or answer keys.\n5. Download `/kaggle/working/results_SL7_final_v16.zip`.\n\nThe notebook runs calibration first and stops if a frozen visual-legibility gate fails.\n\n## Output\nThe scorer creates `scored.csv`, `family_summary.csv`, `summary.md`, `details.json`, plus the raw outputs and environment record.\n'''
(OUT/'README.md').write_text(readme,encoding='utf-8')

# copy this generator source into package
src_self=Path(__file__).resolve()
if src_self != OUT/'generator/make_final_dataset.py': shutil.copy2(src_self, OUT/'generator/make_final_dataset.py')

# ---------- placeholder results ----------
with open(OUT/'results/raw_outputs.csv','w',newline='',encoding='utf-8') as f: csv.writer(f).writerow(['item_id','raw_output','seconds'])
with open(OUT/'results/scored.csv','w',newline='',encoding='utf-8') as f: csv.writer(f).writerow(['Run the notebook to populate final scored results'])
with open(OUT/'results/family_summary.csv','w',newline='',encoding='utf-8') as f: csv.writer(f).writerow(['Run the notebook to populate family summary'])
(OUT/'results/summary.md').write_text('# Results not run yet\n\nRun `run_final_v16.ipynb` once on the frozen package.\n',encoding='utf-8')

# ---------- QC ----------
ids=[r['item_id'] for r in rows_ordered]; unique_ok=(len(ids)==len(set(ids)))
missing=[]; badpre=[]
byidset=set(ids)
for r in rows_ordered:
    for rel in [x for x in r['image_paths'].split('|') if x]:
        if not (OUT/rel).exists(): missing.append((r['item_id'],rel))
    md=json.loads(r['metadata_json'] or '{}')
    for q in md.get('prerequisite_ids',[]):
        if q not in byidset: badpre.append((r['item_id'],q))
# family counts
famcounts={}
for r in scored:
    famcounts.setdefault(r['task_family'],{}).setdefault(r['role'],0); famcounts[r['task_family']][r['role']]+=1
expected={
'B1_zigzag_direction':{'control':10,'probe':10},
'B2_hidden_reconstruction':{'control':10,'probe':10},
'B3_endpoint_anchoring':{'control':10,'probe':10},
'B4_perception_to_action':{'prerequisite':10,'probe':10},
'B5_multi_image_position':{'control':4,'probe':16},
'B6_conditioned_counting':{'control':10,'probe':10},
'B7_multi_source_composition':{'prerequisite':20,'probe':10}}
counts_ok=(famcounts==expected)
# B5 flip checks
b5_ok=True
for sid in set(r['scenario_id'] for r in scored if r['task_family']=='B5_multi_image_position'):
    vv=[r for r in scored if r['task_family']=='B5_multi_image_position' and r['scenario_id']==sid]
    if len(vv)!=2 or vv[0]['correct_answer']==vv[1]['correct_answer']: b5_ok=False
# B7 eligibility structure
b7_ok=True
for i in range(1,11):
    pid=f'B7_P{i:02d}'; md=json.loads(next(r for r in scored if r['item_id']==pid)['metadata_json']);
    if md.get('prerequisite_ids') != [f'B7_C{i:02d}a',f'B7_C{i:02d}b']: b7_ok=False
# image file count
imgfiles=sorted((OUT/'dataset/images').glob('*.png'))
# contact sheet
thumbs=[]
for p in imgfiles:
    im=Image.open(p).convert('RGB'); im.thumbnail((140,140))
    c=Image.new('RGB',(150,175),(244,244,244)); c.paste(im,((150-im.width)//2,0)); d=ImageDraw.Draw(c); d.text((4,145),p.stem[:22],font=FONT_LABEL,fill=BLACK); thumbs.append(c)
cols=6; rr=(len(thumbs)+cols-1)//cols
sheet=Image.new('RGB',(cols*150,rr*175),(235,235,235))
for i,t in enumerate(thumbs): sheet.paste(t,((i%cols)*150,(i//cols)*175))
sheet.save(OUT/'QC_contact_sheet.png')
# hash manifest
manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name!='FILE_HASHES_SHA256.txt':
        manifest.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(OUT)}")
(OUT/'FILE_HASHES_SHA256.txt').write_text('\n'.join(manifest)+'\n',encoding='utf-8')
qc=f'''SL-7 Final Holdout v16 QC\n\nGeneration seed: {GENERATION_SEED}\nTotal rows: {len(rows_ordered)}\nCalibration rows: {len(cal)}\nScored rows: {len(scored)}\nUnique item IDs: {'PASS' if unique_ok else 'FAIL'}\nFamily/role counts: {'PASS' if counts_ok else 'FAIL'}\nImage files: {len(imgfiles)}\nMissing image references: {len(missing)}\nBroken prerequisite references: {len(badpre)}\nB5 swapped-order labels flip: {'PASS' if b5_ok else 'FAIL'}\nB7 prerequisite wiring: {'PASS' if b7_ok else 'FAIL'}\nB7 start+sum stays within same odd-numbered row: PASS (asserted during generation)\nB3 body/empty probes exclude anchored endpoints: PASS (constructed from path geometry)\nContact sheet generated: PASS\nSHA256 manifest generated: PASS\n\nIMPORTANT: This package is frozen before inference. Do not change prompts, images, thresholds, answer keys, or predicted-error metadata after running the final model.\n'''
(OUT/'QC_report.txt').write_text(qc,encoding='utf-8')
if not (unique_ok and counts_ok and not missing and not badpre and b5_ok and b7_ok): raise AssertionError(qc)

# ---------- perfect-answer smoke test ----------
perfect=OUT/'results/perfect_raw_smoketest.csv'
with open(perfect,'w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['item_id','raw_output','seconds']); w.writeheader()
    for r in rows_ordered:w.writerow({'item_id':r['item_id'],'raw_output':r['correct_answer'],'seconds':0})
sys.path.insert(0,str(OUT/'eval'))
import importlib.util
spec=importlib.util.spec_from_file_location('sl7score',OUT/'eval/score.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
smoke=OUT/'results/perfect_score_smoketest'; smoke.mkdir(exist_ok=True)
mod.score(OUT/'dataset/items.csv',perfect,smoke)
scored_smoke=list(csv.DictReader(open(smoke/'scored.csv',encoding='utf-8')))
if not all(int(r['correct'])==1 for r in scored_smoke): raise AssertionError('Perfect-answer smoke test failed')
(OUT/'QC_report.txt').write_text((OUT/'QC_report.txt').read_text()+"Perfect-answer scorer smoke test: PASS\n",encoding='utf-8')
# Remove smoke-test output from final results folder except a note, so users don't confuse it with model results.
shutil.rmtree(smoke); perfect.unlink()

print('Created',OUT)
print('Rows',len(rows_ordered),'Calibration',len(cal),'Scored',len(scored),'Images',len(imgfiles))
