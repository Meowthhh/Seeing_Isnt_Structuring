from PIL import Image, ImageDraw, ImageFont
import math

S=2; SIZE=1000; CELL=100; RSIZE=SIZE*S; RCELL=CELL*S
CREAM=(250,244,220); MINT=(220,239,226); GRID=(104,115,115); OUTER=(76,87,87)
NUM=(28,38,57); STAR=(35,108,220); MAGENTA=(204,0,153)
LADDER_RAIL=(127,73,33); LADDER_RUNG=(215,159,82); LADDER_HIGHLIGHT=(241,202,132)
FONT_PATH='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_NUM=ImageFont.truetype(FONT_PATH,31*S)
NUMBER_OFFSET=(8*S,5*S)

def zz(row,col): return (row-1)*10+col if row%2==1 else row*10-col+1

def cell_fill(row,col): return MINT if (row+col)%2==0 else CREAM

def center(row,col): return ((col-.5)*RCELL,(10-row+.5)*RCELL)

def background():
    im=Image.new('RGB',(RSIZE,RSIZE),(248,248,244)); d=ImageDraw.Draw(im)
    for row in range(1,11):
        for col in range(1,11):
            x0=(col-1)*RCELL; y0=(10-row)*RCELL; fill=cell_fill(row,col)
            d.rectangle([x0,y0,x0+RCELL,y0+RCELL],fill=fill)
    for i in range(11):
        w=2*S if i in (0,10) else 1*S; color=OUTER if i in (0,10) else GRID
        d.line([(i*RCELL,0),(i*RCELL,RSIZE)],fill=color,width=w)
        d.line([(0,i*RCELL),(RSIZE,i*RCELL)],fill=color,width=w)
    return im

def curve(p0,p1,phase=0,amp=16*S,n=100):
    x0,y0=p0; x1,y1=p1; dx=x1-x0; dy=y1-y0; L=max(1,math.hypot(dx,dy)); nx=-dy/L; ny=dx/L
    pts=[]
    for i in range(n):
        t=i/(n-1); wav=math.sin(2.2*math.pi*t+phase)*math.sin(math.pi*t)
        pts.append((x0+dx*t+nx*amp*wav,y0+dy*t+ny*amp*wav))
    return pts

def snake(d,high,low,color,phase=0):
    pts=curve(center(*high),center(*low),phase)
    outline=tuple(max(0,c-55) for c in color)
    # Body stops before the tail point; the last 22% narrows progressively to a sharp tip.
    cut=int(len(pts)*0.78)
    d.line(pts[:cut+1],fill=outline,width=24*S,joint='curve')
    d.line(pts[:cut+1],fill=color,width=19*S,joint='curve')
    tail_pts=pts[cut:]
    for i in range(len(tail_pts)-1):
        frac=i/max(1,len(tail_pts)-2)
        width=max(2*S, int((19*(1-frac)+2)*S))
        ow=max(width+4*S,4*S)
        d.line([tail_pts[i],tail_pts[i+1]],fill=outline,width=ow)
        d.line([tail_pts[i],tail_pts[i+1]],fill=color,width=width)
    # Spots only on the body, never on the tail tip.
    spot=(255,214,74) if sum(color)<500 else (243,90,104)
    for t in [.22,.38,.55,.70]:
        idx=int(t*(cut-1)); x,y=pts[idx]; rr=3.4*S
        d.ellipse([x-rr,y-rr,x+rr,y+rr],fill=spot)
    hx,hy=pts[0]; r=22*S
    d.ellipse([hx-r,hy-r,hx+r,hy+r],fill=outline)
    d.ellipse([hx-r+3*S,hy-r+3*S,hx+r-3*S,hy+r-3*S],fill=color)
    for ex in (-7*S,7*S):
        d.ellipse([hx+ex-5*S,hy-8*S-5*S,hx+ex+5*S,hy-8*S+5*S],fill=(248,248,244))
        d.ellipse([hx+ex-2*S,hy-8*S-2*S,hx+ex+2*S,hy-8*S+2*S],fill=(24,24,24))
    d.line([(hx,hy+13*S),(hx,hy+26*S)],fill=(180,28,54),width=2*S)
    d.line([(hx,hy+26*S),(hx-5*S,hy+31*S)],fill=(180,28,54),width=2*S)
    d.line([(hx,hy+26*S),(hx+5*S,hy+31*S)],fill=(180,28,54),width=2*S)

def ladder(d,low,high,lean=0):
    x0,y0=center(*low); x1,y1=center(*high); x1+=lean*S
    dx=x1-x0; dy=y1-y0; L=math.hypot(dx,dy); px=-dy/L; py=dx/L; half=15*S
    a0=(x0+px*half,y0+py*half); a1=(x1+px*half,y1+py*half); b0=(x0-px*half,y0-py*half); b1=(x1-px*half,y1-py*half)
    for A,B in [(a0,a1),(b0,b1)]:
        d.line([A,B],fill=(81,47,26),width=9*S); d.line([A,B],fill=LADDER_RAIL,width=6*S)
    n=max(3,int(L/(35*S)))
    for i in range(1,n):
        t=i/n; cx=x0+dx*t; cy=y0+dy*t; aa=(cx+px*(half-S),cy+py*(half-S)); bb=(cx-px*(half-S),cy-py*(half-S))
        d.line([aa,bb],fill=(110,65,35),width=6*S); d.line([aa,bb],fill=LADDER_RUNG,width=4*S)

def numbers(d):
    for row in range(1,11):
        for col in range(1,11):
            x=(col-1)*RCELL+NUMBER_OFFSET[0]; y=(10-row)*RCELL+NUMBER_OFFSET[1]
            d.text((x,y),str(zz(row,col)),font=FONT_NUM,fill=NUM,stroke_width=3*S,stroke_fill=cell_fill(row,col))

def star(d,cell):
    cx,cy=center(*cell); R=22*S; r=9*S; pts=[]
    for i in range(10):
        a=-math.pi/2+i*math.pi/5; rr=R if i%2==0 else r; pts.append((cx+math.cos(a)*rr,cy+math.sin(a)*rr))
    d.polygon(pts,fill=STAR,outline=(20,74,160))

def calibration_outline(d,cell):
    # Magenta border with a deliberate top-left notch so the border never touches the number label.
    row,col=cell; x0=(col-1)*RCELL+7*S; y0=(10-row)*RCELL+7*S; x1=col*RCELL-7*S; y1=(11-row)*RCELL-7*S
    w=5*S; gapx=x0+55*S; gapy=y0+43*S
    d.line([(gapx,y0),(x1,y0),(x1,y1),(x0,y1),(x0,gapy)],fill=MAGENTA,width=w)

def render_board(objects,marker=None):
    im=background(); d=ImageDraw.Draw(im)
    for o in objects:
        if o['kind']=='snake': snake(d,tuple(o['high_cell']),tuple(o['low_cell']),tuple(o.get('color',[45,150,110])),o.get('phase',0))
        else: ladder(d,tuple(o['low_cell']),tuple(o['high_cell']),o.get('lean',0))
    numbers(d)
    if marker:
        kind,cell=marker
        if kind=='outline': calibration_outline(d,cell)
        elif kind=='star': star(d,cell)
        # labels are always the top text layer, as in the test images.
        numbers(d)
    return im.resize((SIZE,SIZE),Image.Resampling.LANCZOS)
