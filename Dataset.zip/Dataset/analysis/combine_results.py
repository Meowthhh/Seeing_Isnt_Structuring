import csv,json,zipfile,re,glob,os
from pathlib import Path
from collections import defaultdict

FAMILY_ORDER=[
 "B1_zigzag_direction","B2_hidden_reconstruction","B3_endpoint_anchoring",
 "B4_perception_to_action","B5_multi_image_position","B6_conditioned_counting","B7_multi_source_composition"]
SHORT={
 "B1_zigzag_direction":"B1 Zig-zag direction",
 "B2_hidden_reconstruction":"B2 Hidden reconstruction",
 "B3_endpoint_anchoring":"B3 Endpoint/absence anchoring",
 "B4_perception_to_action":"B4 Perception→action",
 "B5_multi_image_position":"B5 Multi-image position shortcut",
 "B6_conditioned_counting":"B6 Conditioned counting",
 "B7_multi_source_composition":"B7 Multi-source composition"}

def read_zip(path):
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        def read(name):
            return z.read(name).decode('utf-8')
        env=json.loads(read('environment.json')) if 'environment.json' in names else {}
        fam=list(csv.DictReader(read('family_summary.csv').splitlines()))
        summ=read('summary.md') if 'summary.md' in names else ''
        cal={}
        for key in ['number','endpoint','die','multi_image']:
            m=re.search(rf'\| {key} \| (\d+)/(\d+) \| (PASS|FAIL) \|',summ)
            if m: cal[key]={'correct':int(m.group(1)),'n':int(m.group(2)),'pass':m.group(3)=='PASS'}
        cal_pass='**Overall calibration gate:** PASS' in summ
        return env,fam,cal,cal_pass

def collect(search_roots):
    zips=[]
    for root in search_roots:
        root=Path(root)
        if root.is_file() and root.suffix=='.zip': zips.append(root)
        elif root.exists(): zips.extend(root.rglob('results_SL7_*.zip'))
    out=[]; seen=set()
    for p in zips:
        try: env,fam,cal,cal_pass=read_zip(p)
        except Exception as e:
            print('skip',p,e); continue
        mid=env.get('model_id',p.stem)
        # prefer explicit model_id and keep one result per model
        if mid in seen: continue
        seen.add(mid); out.append({'zip':str(p),'env':env,'family':fam,'calibration':cal,'calibration_pass':cal_pass})
    return out

def build(records,out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    long=[]
    for rec in records:
        env=rec['env']; disp=env.get('model_display') or env.get('model_id','unknown')
        for r in rec['family']:
            def fnum(x):
                try:return float(x)
                except:return None
            long.append({
                'model':disp,'model_id':env.get('model_id',''),'parameters':env.get('parameters',''),
                'calibration_pass':rec['calibration_pass'],'family':r['family'],'family_label':SHORT.get(r['family'],r['family']),
                'control_correct':r['control_or_component_correct'],'control_n':r['control_or_component_n'],
                'probe_correct':r['probe_correct'],'probe_n':r['probe_n'],'eligible_probe_n':r['eligible_probe_n'],
                'signature_matches':r['signature_matches'],'probe_errors':r['probe_errors'],
                'gap_pp':r['gap_percentage_points'],'confirmed':int(str(r['confirmed']).strip().lower() in {'1','true','yes'}),
                'mcnemar_p':r['mcnemar_exact_p'],'criteria':r['criteria']})
    fields=list(long[0]) if long else []
    with open(out/'cross_model_family_long.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(long)

    # model x family confirmation matrix
    models=[]
    for r in long:
        if r['model'] not in models: models.append(r['model'])
    lookup={(r['model'],r['family']):r for r in long}
    with open(out/'confirmation_matrix.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['model']+[SHORT[x] for x in FAMILY_ORDER]+['confirmed_count'])
        for m in models:
            vals=[lookup.get((m,x),{}).get('confirmed','') for x in FAMILY_ORDER]
            w.writerow([m]+vals+[sum(v==1 for v in vals)])

    with open(out/'probe_accuracy_matrix.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['model']+[SHORT[x] for x in FAMILY_ORDER])
        for m in models:
            vals=[]
            for x in FAMILY_ORDER:
                r=lookup.get((m,x))
                vals.append(round(100*int(r['probe_correct'])/int(r['probe_n']),1) if r and int(r['probe_n']) else '')
            w.writerow([m]+vals)

    # Markdown summary
    lines=['# SL-7 Cross-Model Summary','',f'Models collected: **{len(models)}**','',
           'A family is counted as confirmed only when that model passes the frozen family-specific SL-7 v16 criterion. Calibration failures should be reported and excluded from headline blind-spot confirmation, not tuned away.','',
           '## Confirmation matrix','']
    lines.append('| Model | ' + ' | '.join(f'B{i}' for i in range(1,8)) + ' | # confirmed |')
    lines.append('|---|'+'---|'*8)
    for m in models:
        vals=[lookup.get((m,x),{}).get('confirmed','') for x in FAMILY_ORDER]
        symbols=['✓' if v==1 else '—' if v==0 else 'NA' for v in vals]
        lines.append('| '+m+' | '+' | '.join(symbols)+f" | {sum(v==1 for v in vals)}/7 |")
    lines += ['', '## Per-family prevalence','', '| Family | Models confirmed |','|---|---:|']
    for x in FAMILY_ORDER:
        n=sum(lookup.get((m,x),{}).get('confirmed')==1 for m in models)
        lines.append(f'| {SHORT[x]} | {n}/{len(models)} |')
    (out/'cross_model_summary.md').write_text('\n'.join(lines),encoding='utf-8')
    return long,models

if __name__=='__main__':
    roots=['/kaggle/input','/kaggle/working']
    records=collect(roots)
    if not records: raise SystemExit('No results_SL7_*.zip files found under /kaggle/input or /kaggle/working')
    build(records,'/kaggle/working/SL7_cross_model_analysis')
    print(Path('/kaggle/working/SL7_cross_model_analysis/cross_model_summary.md').read_text())
