import csv,re,json,math
from pathlib import Path
from collections import defaultdict,Counter
LABELS=['snake head','snake tail','ladder foot','ladder top','no endpoint']

def parse_strict(raw,fmt):
    s=(raw or '').strip().lower()
    if fmt=='integer':
        nums=re.findall(r'(?<!\d)(100|[1-9]?\d)(?!\d)',s)
        return nums[0] if len(nums)==1 else ''
    if fmt=='choice_ab':
        hits=re.findall(r'\b([ab])\b',s)
        return hits[0].upper() if len(hits)==1 else ''
    if fmt=='label':
        hits=[x for x in LABELS if x in s]
        return hits[0] if len(hits)==1 else ''
    return s

def wilson(k,n,z=1.959963984540054):
    if n==0:return ('','')
    p=k/n; den=1+z*z/n; ctr=(p+z*z/(2*n))/den; half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return (max(0,ctr-half),min(1,ctr+half))

def pct(k,n): return 100*k/n if n else float('nan')

def exact_mcnemar(pairs):
    # pairs are tuples (control_correct, probe_correct)
    b=sum(1 for c,p in pairs if c and not p); c=sum(1 for c0,p in pairs if (not c0) and p); n=b+c
    if n==0:return (b,c,1.0)
    m=min(b,c); tail=sum(math.comb(n,k) for k in range(0,m+1))/(2**n); return (b,c,min(1.0,2*tail))

def score(items_csv,raw_csv,out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    items=list(csv.DictReader(open(items_csv,encoding='utf-8')))
    rawrows=list(csv.DictReader(open(raw_csv,encoding='utf-8')))
    preds={r['item_id']:r.get('raw_output','') for r in rawrows}
    rows=[]
    for it in items:
        raw=preds.get(it['item_id'],''); parsed=parse_strict(raw,it['answer_format']); gold=it['correct_answer'].strip().lower()
        ok=bool(parsed) and parsed.lower()==gold
        predset=[x.strip().lower() for x in it.get('predicted_error_values','').split('|') if x.strip()]
        sig=(not ok) and bool(parsed) and parsed.lower() in predset
        md=json.loads(it.get('metadata_json') or '{}')
        rows.append({**it,'raw_output':raw,'parsed_answer':parsed,'correct':int(ok),'matches_predicted_error':int(sig),'missing':int(it['item_id'] not in preds),'metadata':md})
    byid={r['item_id']:r for r in rows}
    for r in rows:
        pre=r['metadata'].get('prerequisite_ids',[]); r['prerequisites_pass']=int(all(byid.get(x,{}).get('correct',0)==1 for x in pre)) if pre else 1
    # write scored.csv without embedded metadata dict
    export=[]
    for r in rows:
        q=dict(r); q.pop('metadata',None); export.append(q)
    with open(out/'scored.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(export[0].keys())); w.writeheader(); w.writerows(export)

    cal=[r for r in rows if r['part']=='CAL']; scored=[r for r in rows if r['part']=='SCORED']
    calgroups=defaultdict(list)
    for r in cal: calgroups[r['task_family']].append(r)
    cal_summary={k:(sum(x['correct'] for x in v),len(v)) for k,v in calgroups.items()}

    fam=defaultdict(list)
    for r in scored:fam[r['task_family']].append(r)
    family_rows=[]; details={}
    def common(name,control_roles=('control',),probe_roles=('probe',)):
        rr=fam[name]; ctr=[r for r in rr if r['role'] in control_roles]; pro=[r for r in rr if r['role'] in probe_roles]
        ck=sum(r['correct'] for r in ctr); pk=sum(r['correct'] for r in pro); errs=[r for r in pro if not r['correct']]; sig=sum(r['matches_predicted_error'] for r in errs)
        gap=(ck/len(ctr)-pk/len(pro)) if ctr and pro else float('nan')
        return rr,ctr,pro,ck,pk,errs,sig,gap

    # B1
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B1_zigzag_direction')
    status=(ck>=8 and pk<=5 and gap>=.30 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='control'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B1_zigzag_direction']={'mcnemar':(mb,mc,mp)}
    family_rows.append(('B1_zigzag_direction',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,mp,'control>=8/10; probe<=5/10; gap>=30pp; >=60% probe errors = T+1'))

    # B2
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B2_hidden_reconstruction')
    status=(ck>=9 and pk<=5 and gap>=.40 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='control'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B2_hidden_reconstruction']={'mcnemar':(mb,mc,mp)}
    family_rows.append(('B2_hidden_reconstruction',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,mp,'control>=9/10; probe<=5/10; gap>=40pp; >=60% errors structural shortcuts'))

    # B3
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B3_endpoint_anchoring')
    status=(ck>=8 and pk<=5 and (sig/len(errs) if errs else 0)>=.60)
    family_rows.append(('B3_endpoint_anchoring',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,'','positive endpoints>=8/10; absence<=5/10; >=60% errors hallucinate endpoint'))

    # B4 prerequisite + eligible probes
    rr=fam['B4_perception_to_action']; ctr=[r for r in rr if r['role']=='prerequisite']; pro=[r for r in rr if r['role']=='probe']; elig=[r for r in pro if r['prerequisites_pass']]
    ck=sum(r['correct'] for r in ctr); pk=sum(r['correct'] for r in elig); errs=[r for r in elig if not r['correct']]; sig=sum(r['matches_predicted_error'] for r in errs); gap=ck/len(ctr)-(pk/len(elig) if elig else 0)
    status=(ck>=8 and len(elig)>=8 and (pk/len(elig) if elig else 1)<=.50 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='prerequisite'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B4_perception_to_action']={'mcnemar':(mb,mc,mp),'snake':{},'ladder':{}}
    for kind in ('snake','ladder'):
        aa=[r for r in pro if r['prerequisites_pass'] and r['metadata'].get('object_kind')==kind]; details['B4_perception_to_action'][kind]={'correct':sum(r['correct'] for r in aa),'n':len(aa)}
    family_rows.append(('B4_perception_to_action',ck,len(ctr),pk,len(elig),len(elig),sig,len(errs),gap,status,mp,'destination>=8/10; eligible action<=50%; >=60% eligible errors stay on landing'))

    # B5
    rr=fam['B5_multi_image_position']; ctr=[r for r in rr if r['role']=='control']; pro=[r for r in rr if r['role']=='probe']; ck=sum(r['correct'] for r in ctr); pk=sum(r['correct'] for r in pro); errs=[r for r in pro if not r['correct']]
    scenario=defaultdict(list)
    for r in pro: scenario[r['scenario_id']].append(r)
    locked=0; lock_n=0
    for sid,v in scenario.items():
        if len(v)==2 and all(x['parsed_answer'] in {'A','B'} for x in v): lock_n+=1; locked+=int(v[0]['parsed_answer']==v[1]['parsed_answer'])
    status=(ck>=3 and pk<=8 and locked>=5)
    bias=Counter(r['parsed_answer'] for r in pro if r['parsed_answer'] in {'A','B'})
    gap=ck/len(ctr)-pk/len(pro)
    details['B5_multi_image_position']={'position_locked':locked,'position_lock_n':lock_n,'A_responses':bias.get('A',0),'B_responses':bias.get('B',0)}
    family_rows.append(('B5_multi_image_position',ck,len(ctr),pk,len(pro),len(pro),'',len(errs),gap,status,'',f'obvious>=3/4; subtle<=8/16; position-lock>=5/8 (observed {locked}/{lock_n})'))

    # B6
    rr,ctr,pro,ck,pk,errs,sig,gap=common('B6_conditioned_counting')
    status=(ck>=8 and pk<=5 and (sig/len(errs) if errs else 0)>=.60)
    pairs=[]
    for pid in sorted(set(r['matched_pair_id'] for r in rr if r['matched_pair_id'])):
        a=[r for r in rr if r['matched_pair_id']==pid and r['role']=='control'][0]; b=[r for r in rr if r['matched_pair_id']==pid and r['role']=='probe'][0]; pairs.append((bool(a['correct']),bool(b['correct'])))
    mb,mc,mp=exact_mcnemar(pairs); details['B6_conditioned_counting']={'mcnemar':(mb,mc,mp)}
    family_rows.append(('B6_conditioned_counting',ck,len(ctr),pk,len(pro),len(pro),sig,len(errs),gap,status,mp,'total>=8/10; filtered<=5/10; >=60% errors return total'))

    # B7
    rr=fam['B7_multi_source_composition']; ctr=[r for r in rr if r['role']=='prerequisite']; pro=[r for r in rr if r['role']=='probe']; ck=sum(r['correct'] for r in ctr); elig=[r for r in pro if r['prerequisites_pass']]; pk=sum(r['correct'] for r in elig)
    errs=[r for r in elig if not r['correct']]; sig=sum(r['matches_predicted_error'] for r in errs); comp_acc=ck/len(ctr); probe_acc=pk/len(elig) if elig else 1; gap=comp_acc-probe_acc
    status=(len(elig)>=8 and probe_acc<=.50 and gap>=.40)
    cats=Counter()
    for r in errs:
        val=r['parsed_answer']; md=r['metadata'];
        if val and val==str(md.get('only_A_answer')): cats['only_A']+=1
        elif val and val==str(md.get('only_B_answer')): cats['only_B']+=1
        elif val: cats['wrong_arithmetic_or_other']+=1
        else: cats['unparsed']+=1
    details['B7_multi_source_composition']={'eligible_scenarios':len(elig),'error_categories':dict(cats)}
    family_rows.append(('B7_multi_source_composition',ck,len(ctr),pk,len(elig),len(elig),sig,len(errs),gap,status,'','>=8/10 scenarios both components correct; eligible composition<=50%; component-composition gap>=40pp'))

    # summary CSV
    fh=['family','control_or_component_correct','control_or_component_n','probe_correct','probe_n','eligible_probe_n','signature_matches','probe_errors','gap_percentage_points','confirmed','mcnemar_exact_p','criteria']
    with open(out/'family_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(fh)
        for x in family_rows:
            name,ck,cn,pk,pn,en,sig,errn,gap,status,mp,criteria=x; w.writerow([name,ck,cn,pk,pn,en,sig,errn,round(100*gap,1),int(status),mp,criteria])

    # Markdown summary
    L=['# SL-7 Final Holdout Summary','',f'Total scored: {len(scored)} | Calibration: {len(cal)}','', '## Calibration gates','', '| Calibration | Correct | Gate |','|---|---:|---|']
    gates={'CAL_number':(7,8),'CAL_endpoint':(3,4),'CAL_die':(4,4),'CAL_multi_image':(3,4)}
    calibration_pass=True
    for name in ['CAL_number','CAL_endpoint','CAL_die','CAL_multi_image']:
        k,n=cal_summary.get(name,(0,0)); need=gates[name][0]; ok=k>=need; calibration_pass &= ok; L.append(f'| {name.replace("CAL_","")} | {k}/{n} | {"PASS" if ok else "FAIL"} |')
    L += ['',f'**Overall calibration gate:** {"PASS" if calibration_pass else "FAIL"}','', '## Seven frozen hypotheses','', '| Family | Control/component | Probe | Gap | Signature | Confirmed | 95% CI control | 95% CI probe |','|---|---:|---:|---:|---:|---|---|---|']
    for x in family_rows:
        name,ck,cn,pk,pn,en,sig,errn,gap,status,mp,criteria=x; clo=wilson(ck,cn); plo=wilson(pk,pn)
        sigtxt=(f'{sig}/{errn}' if isinstance(sig,int) and errn else ('N/A' if sig=='' else str(sig)))
        L.append(f'| {name} | {ck}/{cn} | {pk}/{pn} | {100*gap:.1f} pp | {sigtxt} | **{"YES" if status else "NO"}** | {clo[0]*100:.1f}–{clo[1]*100:.1f}% | {plo[0]*100:.1f}–{plo[1]*100:.1f}% |')
    L += ['', '## Family-specific diagnostics','']
    b5=details['B5_multi_image_position']; L.append(f"- **B5 position-lock:** {b5['position_locked']}/{b5['position_lock_n']} subtle scenarios; A responses {b5['A_responses']}, B responses {b5['B_responses']} across subtle probes.")
    b7=details['B7_multi_source_composition']; L.append(f"- **B7 eligible composition scenarios:** {b7['eligible_scenarios']}/10; error categories: {b7['error_categories']}.")
    b4=details['B4_perception_to_action']; L.append(f"- **B4 eligible snake actions:** {b4['snake'].get('correct',0)}/{b4['snake'].get('n',0)} correct; ladder actions: {b4['ladder'].get('correct',0)}/{b4['ladder'].get('n',0)} correct.")
    L += ['', '## Interpretation policy','', 'These seven families were frozen before this run. A family is counted in the final blind-spot claim only if its pre-registered confirmation rule is satisfied on this holdout. No new blind-spot family should be introduced from these results.', '', '## Per-item failures','']
    for r in scored:
        if not r['correct']:
            elig='eligible' if r['prerequisites_pass'] else 'NOT eligible (prerequisite failed)'; tag='predicted signature' if r['matches_predicted_error'] else 'other error'
            L.append(f"- `{r['item_id']}` ({r['task_family']}, {r['role']}, {elig}): gold `{r['correct_answer']}`, model `{r['parsed_answer'] or r['raw_output']}`, {tag}.")
    (out/'summary.md').write_text('\n'.join(L)+'\n',encoding='utf-8')
    (out/'details.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
    return rows,family_rows,calibration_pass
